<?php
    $connect = mysqli_connect("localhost","root","","quanlycinema");
    if(!$connect){
        die ("Lỗi kết nối". mysqli_connect_error());
    }

?>


