<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>test</title>
  <link rel="stylesheet" href="">
  <script src="vue.js"></script>
  <style>
  h1 {
  color: #1abc9c;
  }
  button {
  border: none;
  background: #1abc9c;
  color: white;
  }
  a {
  color: #1abc9c;
  text-decoration: none;
  }
  a:hover {
  color: red;
}
  </style>
</head>
<body>

<div id="header">
 <h1>Liên hệ theo Số điện thoại này để đặt vé:</h1>
<h1> 0776214895 </h1>
  
<h1> Hoặc 0982671204</h1>
<a href="trangchu.php">Quay lại</a>

</div>
</body>
</html>